<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\calendar\event;

/**
 * @ignore
 */
 
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 *  Event listener.
 */
class listener implements EventSubscriberInterface
{
	/** @var \phpbb\auth\auth */
	protected $auth;
	
	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\event\dispatcher_interface */
	protected $dispatcher;

	/** @var \phpbb\language\language */
	protected $language;
		
	/** @var \phpbb\template\template */
	protected $template;

	/** @var string phpEx */
	protected $php_ext;
	
	protected $events;
	
	/**
	 * Constructor
	 */
	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\event\dispatcher_interface $dispatcher,
		\phpbb\language\language $language,		
		\phpbb\template\template $template,
		$php_ext,
		\steve\calendar\calendar\upcoming_events $events)
	{		
		$this->auth = $auth;
		$this->config = $config;
		$this->helper = $helper;
		$this->dispatcher = $dispatcher;
		$this->language = $language;
		$this->template = $template;
		$this->php_ext = $php_ext;
		$this->events = $events;
	}
	
	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'							=> 'load_language_on_setup',
			'core.permissions'							=> 'add_permission',
			'core.page_header'							=> 'add_page_header_link',
			'core.page_footer_after'					=> 'add_copy',			
			'core.viewonline_overwrite_location'		=> 'viewonline_page',
		);
	}
	
	public function load_language_on_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'steve/calendar',
			'lang_set' => 'common',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}
	
	public function add_page_header_link()
	{
 		if (!$this->auth->acl_get('u_view_calendar') || empty($this->config['calendar_enabled']) || empty($this->config['calendar_version']))
		{
			return;
		}

		$this->template->assign_vars([
			'U_VIEW_CALENDAR'		=> $this->helper->route('steve_calendar_year', ['year' => date("Y")]),
		]);
	}

	public function add_copy()
	{		
	 	if (empty($this->config['calendar_enabled']) || empty($this->config['calendar_version']))
		{
			return;
		}

		$this->template->assign_var('CALENDAR_COPY', $this->language->lang('CALENDAR_COPY', $this->config['calendar_version']));
	}	

	public function viewonline_page($event)
	{
 		if (!$this->auth->acl_get('u_view_calendar') || empty($this->config['calendar_enabled']) || empty($this->config['calendar_version']))
		{
			return;
		}
		//remove app.php
		if ($event['on_page'][1] == 'app' && strrpos($event['row']['session_page'], 'app.' . $this->php_ext . '/Calendar') === 0)
		{
			$event['location'] = $this->language->lang('VIEWING_CALENDAR');
			$event['location_url'] = $event['row']['session_page'];
		}
	}

	public function add_permission($event)
	{
 		if (empty($this->config['calendar_version']))
		{
			return;
		}
				
 		$event['categories'] = array_merge($event['categories'], [
			'calendar'				=> 'ACL_CAT_CALENDAR',
		]);

		$permissions = [
			'u_add_calendar_event' 			=> ['lang' => 'ACL_U_ADD_CALENDAR_EVENT', 		'cat' => 'calendar'],
			'u_attend_calendar_event'		=> ['lang' => 'ACL_U_ATTEND_CALENDAR_EVENT',	'cat' => 'calendar'],
			'u_edit_calendar_event' 		=> ['lang' => 'ACL_U_EDIT_CALENDAR_EVENT', 		'cat' => 'calendar'],
			'u_delete_calendar_event'	 	=> ['lang' => 'ACL_U_DELETE_CALENDAR_EVENT', 	'cat' => 'calendar'],
			'u_unattend_calendar_event'		=> ['lang' => 'ACL_U_UNATTEND_EVENT',			'cat' => 'calendar'],
			'u_view_calendar' 				=> ['lang' => 'ACL_U_VIEW_CALENDAR', 			'cat' => 'calendar'],
			'u_view_calendar_events' 		=> ['lang' => 'ACL_U_VIEW_CALENDAR_EVENTS', 	'cat' => 'calendar'],
		];

		$event['permissions'] = array_merge($event['permissions'], $permissions);
	}
}
