<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\calendar\calendar;

use steve\calendar\calendar\constants;

/**
* Controller
*/
class calendar
{
	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\config\config */
	protected $config;
		
	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\language\language */
	protected $language;
	
	/** @var pagination */
	protected $pagination;
			
	/** @var \phpbb\request\request */
	protected $request;
			
	/** @var \phpbb\template\template */
	protected $template;
	
	/** @var \phpbb\user */
	protected $user;
	
	protected $routing;
	protected  $date;
	protected $calendar_events;
	protected $calendar_events_attending;
	
	/**
	 * Constructor
	*/
	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,		
		\phpbb\db\driver\driver_interface $db,
		\phpbb\controller\helper $helper,
		\phpbb\language\language $language,
		\phpbb\pagination $pagination,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		//
		\steve\calendar\calendar\routing $routing,
		\steve\calendar\calendar\date_time $date,
		$calendar_events,
		$calendar_events_attending)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->db = $db;
		$this->helper = $helper;
		$this->language = $language;
		$this->pagination = $pagination;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		//
		$this->routing = $routing;
		$this->date_time = $date;
		$this->table_calendar_events = $calendar_events;
		$this->table_events_attending = $calendar_events_attending;

		$now = $this->date_time->now();
		$this->now = $now['now'];
		$this->now_year = $now['year'];
		$this->now_month = $now['month']; 
		$this->now_day = $now['day'];	

		$this->language->add_lang('calendar', 'steve/calendar');
	}

	public function get_calendar($year, $months = 0)
	{
		$this->template->assign_vars([
			'NOW_URL'		=> $this->helper->route('steve_calendar_day', ['day_string' => date("D", $this->now), 'day'	=> $this->now_day, 'month' => date('F', $this->now), 'year' => $this->now_year]),
			'NOW_DAY'		=> $this->now_day,
			'NOW_MONTH'		=> $this->now_month,
			'NOW_YEAR'		=> $this->now_year,
			'U_ADD_EVENT'	=> $this->auth->acl_get('u_add_calendar_event') ? $this->helper->route('steve_calendar_add_event', ['action' => 'add', 'event_id' => 0]) : false,
			'VIEW_YEAR'		=> empty($months) ? true : false,
			'CALENDAR'		=> true,
		]);

		$events = $this->get_events($year);
		if (empty($months))
		{
			for ($months = 1; $months <= 12; $months++) 
			{
				$this->get_month($months, $year, $events, true);
			}
		}
		else
		{
			$this->get_month($months, $year, $events, false);	
		}
		unset($events);
		
		return $this;
	}

	public function get_month($months, $year, $events, $view_year = true)
	{
		if (empty($months) || empty($year))
		{
			return false;
		}

		$month_string = $this->date_time->date_key($year, $months, constants::FIRST, "F");

		$this->template->assign_block_vars('calendar', [
			'NOW_MONTH'		=> $this->now_year == $year && $this->now_month == $months ?  true : false,
			'MONTH_STRING'	=> $month_string,
			'MONTH'			=> $months,
			'URL'			=> $this->helper->route('steve_calendar_month', ['month' => $month_string, 'year' => $year]),
		]);
				
		$this->week_days('calendar.week_days', '_D');

		$start_day = $this->date_time->date_key($year, $months, 0, "w");

		$class = $view_year ? 'weekdays-empty-full' : 'weekdays-empty';
		// temp
		$padding = '';
		for ($x = 0; $x < $start_day; $x++)
		{
			$padding .= '<li class="' . $class . '">&nbsp;</li>';
		}

		$this->template->assign_block_vars('calendar.months.padding', [
			'PADDING'		=> $padding,
		]);
		
		$days = $this->date_time->date_key($year, $months, constants::FIRST, "t");

		for ($day = constants::FIRST; $day <= $days; $day++)
		{
			$event_day = $this->date_time->date_key($year, $months, $day, "Y-m-d");

			$is_event = $event_annual = $expired = false;
			if(!empty($events) && !empty($events[$event_day])) 
			{
				foreach ($events[$event_day] as $key => $event) 
				{
					if (empty($event))
					{
						unset($events[$key]);
					}
					$is_event = true;
					$event_annual = $event['annual'] ? true : false;
					$expired = !$event['annual'] && $event['time_stamp'] < $this->now && $this->now_day != $event['day'] && $event['year'] == $year ? true : false;
				}
			}
		
			$day_string = $this->date_time->date_key($year, $months, $day, "D");
			$now_day = $this->now_year == $year && $this->now_day == $day && $this->now_month == $months ?  true : false;//date key
			
			$this->template->assign_block_vars('calendar.months', [
				'DAYS' 		=> !empty($day) ? $day : false,
				'NOW_DAY'	=> $now_day,
				'TITLE'		=> $day_string,
				'URL'		=> $this->helper->route('steve_calendar_day', ['day_string' => $day_string, 'day' => $day, 'month' => $month_string, 'year' => $year]),
				'CLASS'		=> $this->event_class($now_day, $is_event, $event_annual, $expired),
				'ANNUAL'	=> $event_annual,					
			]);
			
			unset($events[$event_day]);//$day
		}

		return $this;
	}
	
	public function event_class($now_day, $is_event, $event_annual, $expired)
	{
		if (empty($is_event))
		{
			return false;
		}
		return $now_day ? 'event-now' : (!empty($event_annual) && $is_event ? 'annual-event' : (!$expired ? 'active-event' : ($expired ? 'expired-event' : '')));
		//return $now_day ? 'event-now' : ($is_event && !$expired ? 'active-event' : ($expired ? 'expired-event' : ($is_event && $event_annual ? 'annual-event' : '')));	
	}

	public function get_events($year)
	{
		if (!$this->auth->acl_get('u_view_calendar_events') || empty($year))
		{
			return false;
		}
		//optimize select
		$sql = 'SELECT *
			FROM ' . $this->table_calendar_events . '
			WHERE year = ' . (int) $year . '
				OR annual = 1';
		$result = $this->db->sql_query($sql);
		//GROUP BY day
		
		$events = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (empty($row))
			{
				continue;
			}

			$key = !empty($row['annual']) ? $year : $row['year'];	
			$events[$this->date_time->date_key($key, $row['month'], $row['day'], "Y-m-d")][] = $row;
		}
		$this->db->sql_freeresult($result);
	
		return $events;
	}

	public function get_month_events($month, $day = 0, $year, $route)
	{
		if (!$this->auth->acl_get('u_view_calendar_events') || empty($month) || empty($year))
		{
			return false;
		}
		
		$page = $this->request->variable('page', 0);
		
		$month_string = $this->db->sql_escape(strtoupper($month));
		$sql_and_day = !empty($day) ? 'AND day = ' . (int) $day : '';
		
		//optimize c for day
		$sql = 'SELECT c.*, u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height
			FROM ' . $this->table_calendar_events . ' c LEFT JOIN ' . USERS_TABLE . ' u ON c.user_id = u.user_id
			WHERE year = ' . (int) $year . '
				AND month_string = "' . $month_string . '"
				' . $sql_and_day . '
					OR (annual = 1 
					AND month_string = "' . $month_string . '"
					' . $sql_and_day . ')
			ORDER BY day ASC, hour ASC, minute ASC';
		$result = $this->db->sql_query_limit($sql, (int) $this->config['calendar_event_limit'], $page);
		
		$this->view_events($result, $month, $year,  $route);
		
		return $this;
	}
	
	public function count_events($month, $day = 0, $year)
	{
		if (!$this->auth->acl_get('u_view_calendar_events') || empty($month) || empty($year))
		{
			return false;
		}
	
		$month_string = $this->db->sql_escape(strtoupper($month));
		$sql_and_day = !empty($day) ? 'AND day = ' . (int) $day : '';
		
		$sql = ' SELECT COUNT(event_id) AS count_events
			FROM ' . $this->table_calendar_events . ' c LEFT JOIN ' . USERS_TABLE . ' u ON c.user_id = u.user_id
			WHERE year = ' . (int) $year . '
				AND month_string = "' . $month_string . '"
				' . $sql_and_day . '
					OR (annual = 1 
					AND month_string = "' . $month_string . '"
					' . $sql_and_day . ')';
		$result = $this->db->sql_query($sql);
		$count_events = $this->db->sql_fetchfield('count_events');
		$this->db->sql_freeresult($result);

		return (int) $count_events;
	}
	
	public function get_event_attendees($event_ids, $year, $count_events)
	{
		if (!$this->auth->acl_get('u_view_calendar_events') || empty($event_ids) || empty($year) || empty($count_events))
		{
			return false;
		}
		//optimize
		$sql = 'SELECT c.*, u.user_id, u.username, u.user_colour
			FROM ' . $this->table_events_attending  . ' c LEFT JOIN ' . USERS_TABLE . ' u ON c.user_id = u.user_id
			WHERE ' . $this->db->sql_in_set('event_id', array_unique($event_ids)) . '
				AND year = ' . (int) $year . '
			ORDER BY username ASC';
		$result = $this->db->sql_query($sql);

		$attendees = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (empty($row))
			{
				continue;
			}
			$attendees[(int) $row['event_id']][] = $row;
		}
		$this->db->sql_freeresult($result);

		return $attendees;
	}
		
	public function view_events($result, $month, $year, $route)
	{
		if (empty($result) || empty($month) || empty($year))
		{
			return false;
		}

		$events = $event_ids = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (empty($row))
			{
				continue;
			}
			$event_ids[] = (int) $row['event_id'];
			$events[] = $row;// (int) $row['event_id']
		}
		$this->db->sql_freeresult($result);
			
		$count_events = $this->count_events($month, !empty($day) ? $day : 0, $year);
		
		$attendees = $this->get_event_attendees($event_ids, $year, $count_events);

		if (!empty($events))
		{
			foreach ($events as $event)
			{
				if (empty($event))
				{
					continue;
				}
				//? 5.5//event_timestamp($year, $month, $day, $hour, $min)
				if (!empty($event['annual']))
				{
					try
					{
						$timezone = !empty($this->user->data['user_timezone']) ? $this->user->data['user_timezone'] : $this->config['board_timezone'];
					}
					catch (\Exception $e)
					{
						$timezone = 'UTC';
					}
					$now = new \DateTime("$year-{$event['month']}-{$event['day']} {$event['hour']}:{$event['minute']}", new \DateTimeZone($timezone));
					$time_stamp = $now->getTimeStamp();// + $now->getOffset();
				}

				$time_stamp = empty($event['annual']) ? $event['time_stamp'] : $time_stamp;
				$expired = $event['time_stamp'] < $this->now && $this->now_day != $event['day'] && $event['year'] == $year ? true : false;
				$year_js = empty($event['annual']) ? $event['year'] : $year;
				
				$now_day = $this->now_year == $year_js && $this->now_day == $event['day'] && $this->now_month == $event['month'] ?  true : false;//
								
				$day_string = $this->date_time->date_key($year_js, $event['month'], $event['day'], "D");

				$month_string = $this->date_time->date_key($year_js, $event['month'], constants::FIRST, "F");
				$day_route = $this->helper->route('steve_calendar_day', ['day_string' => $day_string, 'day' => $event['day'], 'month' => $month_string, 'year' => $year_js]);
				
				$template_vars = [
					'EVENT_ID'			=> $event['event_id'],
					'USER_AVATAR'		=> get_user_avatar($event['user_avatar'], $event['user_avatar_type'], $event['user_avatar_width'], $event['user_avatar_height']),
					'USER_NAME'			=> get_username_string('full', $event['user_id'], $event['username'], $event['user_colour']),
					'USER_AVATAR_URL'	=> get_username_string('profile', $event['user_id'], $event['username'], $event['user_colour']),
					'TIME_STAMP' 		=> $this->user->format_date($time_stamp),
					'TIME_ZONE'			=> $event['time_zone'],
					'DAY'         		=> $this->date_time->date_key($year_js, $event['month'], $event['day'], "jS"),
					'DAY_STRING'  		=> $this->language->lang(empty($event['annual']) ? $event['day_string'] : $this->date_time->date_key($year, $event['month'], $event['day'], "l")),
					'CLASS'				=> $now_day ? 'event-now' : (!empty($event['annual']) ? 'annual-event' : (!$expired ? 'active-event' : ($expired ? 'expired-event' : ''))),
					'FA'				=> !empty($event['annual']) ? 'fa-calendar' : (!$expired ? 'fa-calendar-check-o' : 'fa-calendar-minus-o'),
					'TITLE'				=> censor_text($event['title']),
					'INFORMATION'		=> $this->information($event, true),
					'U_ATTEND'			=> $this->auth->acl_get('u_attend_calendar_event') && !$expired ? $this->helper->route('steve_calendar_attend_event', ['action' => 'attend', 'event_id' => $event['event_id'], 'year' => $year_js, 'hash' => generate_link_hash('attend')]) : false,
					'U_UNATTEND'		=> $this->auth->acl_get('u_unattend_calendar_event') ? $this->helper->route('steve_calendar_attend_event', ['action' => 'unattend', 'event_id' => $event['event_id'], 'year' => $year_js, 'hash' => generate_link_hash('unattend')]) : false,
					'U_DELETE'			=> $this->u_event_action('u_delete_calendar_event', $event['user_id']) ? $this->helper->route('steve_calendar_delete_event', ['event_id' => $event['event_id'], 'hash' => generate_link_hash('delete')]) : false,
					'U_EDIT'			=> $this->u_event_action('u_edit_calendar_event', $event['user_id']) ? $this->helper->route('steve_calendar_add_event', ['action' => 'edit', 'event_id' => $event['event_id']]) : false,
				];
				
				$this->template->assign_block_vars('events', $template_vars);
				
				if (!empty($attendees[$event['event_id']]))
				{
					foreach ($attendees[$event['event_id']] as $attendee)
					{		
						$this->template->assign_block_vars('events.attendees', [
							'USER_NAME'			=> get_username_string('full', $attendee['user_id'], $attendee['username'], $attendee['user_colour']),
							'U_UNATTEND'		=> $attendee['user_id'] == $this->user->data['user_id'] && $this->auth->acl_get('u_unattend_calendar_event') ? $this->helper->route('steve_calendar_attend_event', ['action' => 'unattend', 'event_id' => $event['event_id'], 'year' => $year_js, 'hash' => generate_link_hash('unattend')]) : false,			
						]);
					}
					unset($attendees[$event['event_id']]);
				}
			}
			unset($events);

			$page = $this->request->variable('page', 0);
			
			$this->pagination->generate_template_pagination($route, 'pagination', 'page', $count_events, (int) $this->config['calendar_event_limit'], $page);
		}

		return $this;
	}
	
	public function u_event_action($auth_action, $user_id)
	{
		return (bool) $this->auth->acl_get($auth_action) && ($user_id == $this->user->data['user_id'] || $user_id != $this->user->data['user_id'] && $this->auth->acl_get('a_')) ? true : false;
	}
	//temp
	public function week_days($block, $prefix)
	{	
		$week_days = new constants;
		$week_days = $week_days->days_to_array(true);
		
		foreach ($week_days as $week_day)
		{
			$this->template->assign_block_vars($block, [
				'DAYS'		=> $this->language->lang($week_day . $prefix),
			]);
		}
		unset($week_days);
		
		return $this;
	}
//
	public function flags()
	{
		return (bool) ($this->config['allow_bbcode'] ? OPTION_FLAG_BBCODE : false) + ($this->config['allow_smilies'] ? OPTION_FLAG_SMILIES : false) + ($this->config['allow_post_links'] ? OPTION_FLAG_LINKS : false);
	}
//	
	public function information($event, $truncate = false)
	{
		//$event['information'] = truncate_string($event['information'], 255, 255, true, '....') ;
		return (string) generate_text_for_display($event['information'], $event['bbcode_uid'], $event['bbcode_bitfield'], $this->flags(), true);
	}
}
