<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\calendar\calendar;

use steve\calendar\calendar\constants;

/**
* 
*/
class routing
{
	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\language\language */
	protected $language;
		
	/** @var \phpbb\template\template */
	protected $template;
	
	/** @var \phpbb\user */
	protected $user;
	
	protected $date;
	
	/**
	 * Constructor
	*/
	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\language\language $language,
		\phpbb\template\template $template,
		\steve\calendar\calendar\date_time $date)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->helper = $helper;
		$this->language = $language;
		$this->template = $template;
		$this->date_time = $date;
		
		$this->language->add_lang('calendar', 'steve/calendar');
	}

	public function year_next_prev($year)
	{
		$this->template->assign_vars([
			'YEAR'				=> $year,
			'YEAR_URL'			=> $this->helper->route('steve_calendar_year', ['year' => $year]),
			'NEXT_YEAR'			=> $year + 1,
			'NEXT_YEAR_URL'		=> $this->helper->route('steve_calendar_year', ['year' => $year + 1]),
			'PREV_YEAR'			=> $year - 1,
			'PREV_YEAR_URL'		=> $this->helper->route('steve_calendar_year', ['year' => $year - 1]),
		]);
		
		return $this;
	}
	
	public function month_next_prev($month, $year)
	{
		$month_key = strtoupper($month);
		$this->template->assign_vars([
			'MONTH_YEAR'		=> $this->language->lang($month_key) . ' ' . $year,
			'MONTH'				=> $this->language->lang($month_key),
			'MONTH_URL'			=> $this->helper->route('steve_calendar_month', ['month' => $month, 'year' => $year]),
			'NEXT_MONTH'		=> $this->date_time->adjust_date('P1M', $year, $this->date_time->month_int($month), constants::FIRST, true),
			'NEXT_MONTH_URL'	=> $this->helper->route('steve_calendar_month', [
				'month' 	=> $this->date_time->adjust_date('P1M', $year, $this->date_time->month_int($month), constants::FIRST, true), 
				'year' 		=> $month_key == constants::DEC ? $year + 1 : $year]
			),
			'PREV_MONTH'		=> $this->date_time->adjust_date('P1M', $year, $this->date_time->month_int($month), constants::FIRST, false),
			'PREV_MONTH_URL'	=> $this->helper->route('steve_calendar_month', [
				'month' 	=> $this->date_time->adjust_date('P1M', $year, $this->date_time->month_int($month), constants::FIRST, false), 
				'year' 		=> $month_key == constants::JAN ? $year - 1 : $year]
			),
		]);
		
		return $this;
	}
	
	public function day_next_prev($day, $month, $year)
	{						
		$this->template->assign_vars(array(
			'DAY_J'			=> $this->date_time->date_key($year, $this->date_time->month_int($month), $day, "jS"),
			'DAY_STRING'	=> $this->date_time->date_key($year, $this->date_time->month_int($month), $day, "D"),
		));
			
		return $this;				
	}
	
	public function validate_day($day_string, $day)
	{	
		$days = new constants;
		if (!in_array(strtoupper($day_string), $days->days_to_array(false)) || $day_string == '' || strlen($day_string) > (int) 3
			|| !is_numeric($day) || intval($day) == 0 || intval($day) > constants::LAST_D)
		{
			throw new \phpbb\exception\http_exception(403, 'INVALID_ROUTE_DAY');				
		}
		
		return $this;
	}
	
	public function validate_month($month)
	{
		$months = new constants;
		if (!in_array(strtoupper($month), $months->months_to_array(true)))
		{
			throw new \phpbb\exception\http_exception(403, 'INVALID_ROUTE_MONTH');				
		}
		
		return $this;
	}
	
	public function validate_year($year)
	{
		if (!is_numeric($year))
		{
			throw new \phpbb\exception\http_exception(403, 'CALENDAR_YEAR_INVALID');
		}
		if (empty($year))
		{
			throw new \phpbb\exception\http_exception(404, 'CALENDAR_YEAR_EMPTY');		
		}
		
		return $this;
	}
}
