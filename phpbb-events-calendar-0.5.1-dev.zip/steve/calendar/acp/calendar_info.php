<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\calendar\acp;

/**
 * ACP module info.
 */
class calendar_info
{
	public function module()
	{
		return array(
			'filename'	=> '\steve\calendar\acp\calendar_module',
			'title'		=> 'ACP_CALENDAR_TITLE',
			'modes'		=> [
				'settings'	=> [
					'title'		=> 'ACP_CALENDAR_SETTINGS',
					'auth'		=> 'ext_steve/calendar && acl_a_board',
					'cat'		=> ['ACP_CALENDAR_TITLE']
				],			
			],
		);
	}
}
