<?php
/**
 *
 * Events Calendar An extension for the phpBB 3.2.0 Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 * 
 */

namespace steve\calendar\controller;

/**
* Controller
*/
class calendar_view
{
	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\config\config */
	protected $config;
	
	/** @var \phpbb\controller\helper */
	protected $helper;
	
	/** @var \phpbb\language\language */
	protected $language;
	
	/** @var pagination */
	protected $pagination;
			
	protected $calendar;
	protected $routing;
	
	/**
	 * Constructor
	*/
	public function __construct(
		\phpbb\auth\auth $auth, 
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\language\language $language,
		\phpbb\pagination $pagination,
		\steve\calendar\calendar\calendar $calendar,
		\steve\calendar\calendar\routing $routing)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->helper = $helper;
		$this->language = $language;
		$this->pagination = $pagination;
		$this->calendar = $calendar;
		$this->routing = $routing;

		$this->language->add_lang('common', 'steve/calendar');
 		if (!$this->auth->acl_get('u_view_calendar'))
		{
			throw new \phpbb\exception\http_exception(403, 'NO_AUTH_CALENDAR');
		}
 		if (empty($this->config['calendar_enabled']) || empty($this->config['calendar_version']))
		{
			throw new \phpbb\exception\http_exception(404, 'CALENDAR_DISABLED');
		}
	}

	public function view_year($year)
	{
		$this->routing->validate_year($year)
			->year_next_prev($year);

		$this->calendar->get_calendar($year, 0);
		
		return $this->helper->render('calendar.html', $this->language->lang('CALENDAR_YEAR', $year));
	}

	public function view_month($month, $year)
	{
		$this->routing->validate_year($year)
			->validate_month($month)
			->year_next_prev($year)
			->month_next_prev($month, $year);

		$month_route = $this->helper->route('steve_calendar_month', ['month' => $month, 'year' => $year]);
				
		$this->calendar->get_calendar($year, date("n", strtotime($month)))
			->get_month_events($month, 0, $year, $month_route);

		return $this->helper->render('calendar.html', $this->language->lang('CALENDAR_MONTH', $month, $year));
	}

	public function view_day($day_string, $day, $month, $year)
	{
		$this->routing->validate_year($year)
			->validate_month($month)
			->validate_day($day_string, $day)
			->year_next_prev($year)
			->month_next_prev($month, $year)
			->day_next_prev($day, $month, $year);

		$day_route = $this->helper->route('steve_calendar_day', ['day_string' => $day_string, 'day' => $day, 'month' => $month, 'year' => $year]);

		$this->calendar->get_calendar($year, date("n", strtotime($month)), $day_route)
			->get_month_events($month, $day, $year, $day_route);

		return $this->helper->render('calendar.html', $this->language->lang('CALENDAR_DAY', $day_string, $day, $month, $year));
	}
}
